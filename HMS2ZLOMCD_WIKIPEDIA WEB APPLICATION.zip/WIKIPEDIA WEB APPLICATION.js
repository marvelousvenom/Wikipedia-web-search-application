let searchInputElement = document.getElementById('searchInput');
let searchResultsElement = document.getElementById('searchResults');
let spinnerElement = document.getElementById('spinner');

function createAndAppendSearchResults(result) {
    let {
        title,
        link,
        description
    } = result;
    //1.Div container -- result-item
    let divContainerElement = document.createElement('div');
    divContainerElement.classList.add('result-item');
    searchResultsElement.appendChild(divContainerElement);

    //2.anchor element -- result-title
    let anchorElement = document.createElement('a');
    anchorElement.classList.add('result-title');
    anchorElement.textContent = title;
    anchorElement.href = link;
    anchorElement.target = "_blank";
    divContainerElement.appendChild(anchorElement);


    //3. title-break
    let breakElement = document.createElement('br');
    divContainerElement.appendChild(breakElement);

    //4.anchor -- result-url
    let urlElement = document.createElement('a');
    urlElement.classList.add('result-url');
    urlElement.href = link;
    urlElement.target = "_blank";
    urlElement.textContent = link;
    divContainerElement.appendChild(urlElement);

    //5.Line Break 
    let lineBreakElement = document.createElement("br");
    divContainerElement.appendChild(lineBreakElement);

    //6.paragraph -- line discription
    let desElement = document.createElement("p");
    desElement.classList.add('line-description');
    desElement.textContent = description;
    divContainerElement.appendChild(desElement);
}




function displayResults(search_results) {
    spinnerElement.classList.toggle("d-none");
    for (let result of search_results) {
        createAndAppendSearchResults(result);
    }
}

function searchwikipedia(event) {
    if (event.key === 'Enter') {
        searchResultsElement.textContent = "";
        spinnerElement.classList.toggle("d-none");
        let searchInput = searchInputElement.value;
        let url = "https://apis.ccbp.in/wiki-search?search=" + searchInput;
        let options = {
            method: "GET"
        };
        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                let {
                    search_results
                } = jsonData;
                displayResults(search_results);
            });
    }
}

searchInputElement.addEventListener("keydown", searchwikipedia);